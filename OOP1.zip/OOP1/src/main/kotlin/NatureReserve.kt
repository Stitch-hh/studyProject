open class NatureReserve {

    companion object {
        val listOfAnimals = mutableListOf<Animal>(Bird(), Bird(),
            Bird(), Bird(), Bird(), Fish(), Fish(),
            Fish(), Dog(), Dog(), Animal(), Animal())
    }


}